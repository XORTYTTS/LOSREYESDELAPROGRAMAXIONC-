#include "Arduino.h"

void GetValues();

